<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Booking Calendar</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="calendar">
        <div class="calendar-header">
            <button id="prev" class="nav-btn">&lt;</button>
            <h2 id="monthYear"></h2>
            <button id="next" class="nav-btn">&gt;</button>
        </div>
        <div class="calendar-body">
            <div class="calendar-weekdays">
                <div>Su</div>
                <div>Mo</div>
                <div>Tu</div>
                <div>We</div>
                <div>Th</div>
                <div>Fr</div>
                <div>Sa</div>
            </div>
            <div class="calendar-dates" id="calendar-dates"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Booking Calendar</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="calendar">
        <div class="calendar-header">
            <button id="prev" class="nav-btn">&lt;</button>
            <h2 id="monthYear"></h2>
            <button id="next" class="nav-btn">&gt;</button>
        </div>
        <div class="calendar-body">
            <div class="calendar-weekdays">
                <div>Su</div>
                <div>Mo</div>
                <div>Tu</div>
                <div>We</div>
                <div>Th</div>
                <div>Fr</div>
                <div>Sa</div>
            </div>
            <div class="calendar-dates" id="calendar-dates"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
