<!DOCTYPE html>


    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Bejelentkezés</title>   
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
    </head>
<body>

    
</div>

   

</div>

<?php

    $user = mysqli_fetch_array(mysqli_query($adb, "

                        SELECT * FROM user WHERE uid = '$_SESSION[uid]'

    "));



?>
<div class="profilFormContainer">
    
    <form action='adatlap.php' method=post target='kisablak' id="profilform" enctype='multipart/form-data'>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Profil adatlap</h3>
            
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Username -->
            <label for="unick">Felhasználónév</label>
            <input type="text" placeholder="" name="unick" required value="<?=$user['unick'];?>">

            <label for="unev">Teljes név</label>
            <input type="text" placeholder="" name="unev" value="<?=$user['unev'];?>">
            <br>
            <br>

            <!-- Email -->
            <label for="uemail">Email</label>
            <input  placeholder="" name="uemail" type='email' value="<?=$user['uemail'];?>">

            <label for="uwmail">Weisses Email</label>
            <input  placeholder="" name="uwmail" type='email' value="<?=$user['uwmail'];?>">
            <br>
            <br>

            <!-- OM azonoító -->
            <label for="uom">OM azonosító</label>
            <input type="text" placeholder="" name="uom" value="<?=$user['uom'];?>">

            <br>
            <br>
            <!-- Password -->
            <label for="upw">Jelszava</label>
            <input type="password" name="upw" required>

            <br>
            <br>

            
            <label for="upw1">Profilkep</label>
            <input type="file" name="uprofkep">
            <!-- Submit button -->
            <button type="submit" id="profilformgomb">Módosítások alkalmazása</button>

       
        </div>

    </form>
</div>
</body>
</html>
