<!DOCTYPE html>


    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Bejelentkezés</title>   
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
    </head>
<body>

    
</div>

    

</div>
<div class="profilFormContainer">
    
    <form action='' method=post target='kisablak' id="profilform" enctype='multipart/form-data'>
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Profil adatlap</h3>
            
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Username -->
            <label for="unick">Felhasználónév</label>
            <input type="text" placeholder="" name="unick" required>

            <label for="unev">Teljes név</label>
            <input type="text" placeholder="" name="unev" required>
            <br>
            <br>

            <!-- Email -->
            <label for="uemail">Email</label>
            <input  placeholder="" name="uemail" required type='email'>

            <label for="uwmail">Weisses Email</label>
            <input  placeholder="" name="uwmail" required type='email'>
            <br>
            <br>

            <!-- OM azonoító -->
            <label for="uom">OM azonosító</label>
            <input type="text" placeholder="" name="uom" required>

            <br>
            <br>
            <!-- Password -->
            <label for="upw1">Jelszava</label>
            <input type="password" placeholder="Legalább 8 karakter" name="upw1" required>

            <br>
            <br>


            <!-- Submit button -->
            <button type="submit" id="profilformgomb">Módosítások alkalmazása</button>

       
        </div>

    </form>
</div>
</body>
</html>
<?php



?>