function menunyitas(){
    document.getElementById("felsorolas").classList.toggle("open");
}