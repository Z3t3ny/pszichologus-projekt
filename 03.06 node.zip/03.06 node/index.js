// tangletrack.com | smartin.hu
const express = require("express")
const mysql = require("mysql")

const app = express()
const port = 8080

app.use(express.json())

app.listen(port, ()=> {
    console.log("A szerver ezen a porton fut: " + port.toString())
})

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "users_db"
})
db.connect(err => {
    if (err) {
        console.log("Sikertelen csatlakozás az adatbázishoz. Hiba: " + err.message)
    }
    else {
        console.log("Sikeres csatlakozás az adatbázishoz.")
    }
})

app.get("/", (req, res) => {
    res.send("Valami szoveg!")
})

app.get("/users", (req, res) => {
    db.query("SELECT * FROM users", (err, result) => {
        if (err) {
            res.send(err.message)
        }
        else {
            res.send(result)
        }
    })
})

app.get("/users:id", (req, res) => {
    const id = req.params.id

    db.query(`SELECT * FROM users WHERE id = ${id}`, (err, result) => {
        if (err) {
            res.json(err.message)
        }
        else if (result == "") {
            res.send("Nem található a keresett felhasználó!")
        }
        else {
            res.json(result)
        }
    })

})

app.post("/users", (req, res) => {
    const uname = req.body.name
    const uemail = req.body.email

    db.query(`INSERT INTO users (name, email) VALUE ("${uname}", "${uemail}")`, (err) => {
        if (err) {
            res.json(err.message)
            console.log("Nem sikerült hozzáadni a felhasználót.")
        }
        else {
            res.json({uname, uemail})
        }
    })
})

app.delete("/users:id", (req, res) => {
    const uid = parseInt(req.params.id);

    db.query(`DELETE FROM users WHERE id = ${uid}`, (err, result) => {
        if (err) {
            res.json({ success: false, message: "Nem sikerült törölni a felhasználót.", error: err.message });
        }
        else if (result.affectedRows === 0) {
            res.json({ success: false, message: "Nincs ilyen ID-vel rendelkező felhasználó." });
        }
        else {
            res.json({ success: true, message: "Felhasználó sikeresen törölve." });
        }
    })
})

app.put("/users:id", (req, res) => {
    const uid = parseInt(req.params.id);
    const uname = req.body.name
    const uemail = req.body.email

    db.query("UPDATE users SET name = ?, email = ? WHERE id = ?", [uname, uemail, uid], (err, result) => {
        if (err) {
            res.json(err.message)
            console.log("Nem sikerült módosítani a felhasználó adatait.")
        }
        else {
            res.json({uname, uemail})
        }
    })
})
