<?php
session_start();

// Ha a felhasználó már be van jelentkezve, átirányítjuk az admin oldalra
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin_foglalasok.php");
    exit();
}

// Bejelentkezési adatok kezelése
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Itt a valódi rendszerben hashelni kellene a jelszót és adatbázisból kellene ellenőrizni
    $admin_username = "admin"; // Ezt cseréld ki valódi felhasználónévre
    $admin_password = "admin123"; // Ezt cseréld ki valódi jelszóra (hashelve)
    
    if ($_POST['username'] === $admin_username && $_POST['password'] === $admin_password) {
        // Sikeres bejelentkezés
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin_username;
        
        // IP cím és bejelentkezési idő rögzítése (opcionális)
        $ip = $_SERVER['REMOTE_ADDR'];
        $date = date('Y-m-d H:i:s');
        // Itt lehetne menteni a bejelentkezési adatokat az adatbázisba
        
        header("Location: admin_foglalasok.php");
        exit();
    } else {
        $error = "Hibás felhasználónév vagy jelszó!";
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Bejelentkezés</title>
    <link href="pszichologus.css" type="text/css" rel="stylesheet">
    <style>
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .error-message {
            color: #a94442;
            background-color: #f2dede;
            border: 1px solid #ebccd1;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Admin Bejelentkezés</h1>
        
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <label for="username">Felhasználónév:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Jelszó:</label>
            <input type="password" id="password" name="password" required>
            
            <button class="idopontbutton"type="submit">Bejelentkezés</button>
        </form>
    </div>
</body>
</html>