<html><head>
    <link rel="shortcut icon" href="/wmicon.ico" type="image/vnd.microsoft.icon">
    <title> WEISSes vagyok </title>

    <link href="pszihologus.css" type="text/css" rel="stylesheet">
</head>

<body>

<div id="tartalom">
<h1> Aktuális mérések </h1>


	<div id="szoveg">

		<blockquote>

			<ul> 
				<li><a href="/meresek/iskola24-tanuloi-kerdoiv/">Tanulói kérdőív az iskola értékeléséhez</a>

				<br><br>

				</li><li>Tanári kérdőív a kollégium értékeléséhez

				<br><br>

				</li><li>Szülői kérdőív a kollégium értékeléséhez

			</li></ul> 

		</blockquote>

	</div>	


<br><br><hr><br><br>



<h1> Korábbi mérések </h1>


<div id="szoveg">

	<blockquote>

		<ul> 

			<li><a href="/meresek/tanarertekeles/">Tanulói kérdőív a pedagógusok értékeléséhez - 2023. április</a>

			<br><br>

			</li><li><a href="/meresek/digitalisoktatas/">Digitális oktatás kérdőív - Válaszok</a>

		</li></ul> 


	</blockquote>

</div>


    </div>




</body></html>