<?php
if (isset($_GET['tid'])) {
    $tid = $_GET['tid'];

    // Kapcsolódás az adatbázishoz
    $conn = new mysqli("sql204.infinityfree.com", "if0_38415749", "wbEJgydD4SM", "if0_38415749_wv");

    if ($conn->connect_error) {
        die("Kapcsolódási hiba: " . $conn->connect_error);
    }

    // Lekérdezés a termékről és a felhasználóról
    $sql = "SELECT t.tid, t.tnev, t.tar, t.tkep, t.tdescrip, u.uid, u.uname, u.uprofilepic 
            FROM termekek t
            JOIN user u ON t.tuid = u.uid
            WHERE t.tid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $tid);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        echo "<div class='product-details'>";
        echo "<div class='user-profile'>";
        echo "<img src='./userprofilepics/" . $product['uprofilepic'] . "' alt='Profilkép'>";
        echo "<span>" . $product['uname'] . "</span>";
        echo "</div>";
        echo "<img src='./termekkepek/" . $product['tkep'] . "' alt='" . $product['tnev'] . "'>";
        echo "<div>";
        echo "<h3>" . $product['tnev'] . "</h3>";
        echo "<p>" . $product['tdescrip'] . "</p>";
        echo "<p>" . $product['tar'] . " Ft</p>";
        echo "<form action='adokveszek_ir.php' method='POST'>";
        echo "<input type='hidden' name='tid' value='" . $product['tid'] . "'>";
        echo "<button type='submit'>Mentés a kedvencekhez</button>";
        echo "</form>";
        echo "<button onclick='alert(\"Vásárlás gomb még nem működik\")'>Vásárlás</button>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "Nincs ilyen termék.";
    }

    $stmt->close();
    $conn->close();
}
?>
