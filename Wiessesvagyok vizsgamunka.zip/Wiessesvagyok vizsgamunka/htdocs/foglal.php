<?php
//header('Content-Type: application/json');

// Adatbázis kapcsolat
require_once 'kapcsolat.php';

// Foglalások lekérdezése (üres tömb, ha nincs foglalás)
$occupied_slots = [];
$sql = "SELECT fdatum, fido FROM foglalasok WHERE fstatusz = 'elfogadva'";
$result = $adb->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $occupied_slots[] = [
            'date' => $row['fdatum'],
            'time' => $row['fido']
        ];
    }
}

// Ha GET kérés érkezett, csak a foglalt időpontokat adjuk vissza
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(['occupied_slots' => $occupied_slots]);
    exit;
}

// POST kérés feldolgozása (új foglalás)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Adatok ellenőrzése
    if (empty($data['reason']) || empty($data['date']) || empty($data['time'])) {
        echo json_encode(['success' => false, 'message' => 'Minden mező kitöltése kötelező!']);
        exit;
    }

    // Dátum ellenőrzése
    $selected_date = new DateTime($data['date']);
    $day_of_week = $selected_date->format('w'); // 0=Vasárnap, 6=Szombat
    
    if ($day_of_week == 0 || $day_of_week == 6) {
        echo json_encode(['success' => false, 'message' => 'Hétvégén nem lehet időpontot foglalni!']);
        exit;
    }

    // Időpont ellenőrzése (foglalt-e már)
    $time = $data['time'];
    $date = $data['date'];
    
    foreach ($occupied_slots as $slot) {
        if ($slot['date'] === $date && $slot['time'] === $time) {
            echo json_encode(['success' => false, 'message' => 'Ez az időpont már foglalt!']);
            exit;
        }
    }

    // Foglalás rögzítése az adatbázisban
    try {
        $stmt = $adb->prepare("INSERT INTO foglalasok (findok, fdatum, fido, fstatusz, frogzites_datum) VALUES (?, ?, ?, 'függőben', NOW())");
        $stmt->bind_param("sss", $data['reason'], $data['date'], $data['time']);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Foglalás sikeresen elküldve! Az adminisztrátor hamarosan megerősíti.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Hiba történt a foglalás során.']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Adatbázis hiba: ' . $e->getMessage()]);
    }
    
    $adb->close();
    exit;
}

echo json_encode(['success' => false, 'message' => 'Érvénytelen kérés.']);
?>