<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="pszichologus.css" type="text/css" rel="stylesheet">
  <title>Időpontfoglalás</title>
  <style>
    .occupied-slot {
      color: #d9534f;
      font-weight: bold;
    }
    .time-option {
      position: relative;
    }
    .time-option.occupied::after {
      content: " (Foglalt)";
      color: #d9534f;
      font-size: 0.8em;
    }
    .admin-login-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background-color: #4CAF50;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
    }
    .container {
      position: relative;
    }
    textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
      resize: vertical;
      min-height: 100px;
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="admin_login.php" class="admin-login-btn">Admin bejelentkezés</a>
    
    <h2>Időpontfoglalás</h2>
    <form id="bookingForm" class="idopontfoglalasform" method="POST" action="foglal.php">
      <label for="reason">Indok (miért szeretne időpontot foglalni):</label>
      <textarea id="reason" required></textarea>

      <label for="date">Dátum:</label>
      <input type="date" id="date" required>

      <label for="time">Időpont:</label>
      <select id="time" required>
        <option value="">Válassz időpontot</option>
        <option value="08:00">08:00</option>
        <option value="08:55">08:55</option>
        <option value="09:50">09:50</option>
        <option value="10:50">10:50</option>
        <option value="11:45">11:45</option>
        <option value="12:40">12:40</option>
        <option value="13:30">13:30</option>
        <option value="14:20">14:20</option>
      </select>

      <button class="idopontbutton" type="submit">Foglalás</button>
    </form>

    <div class="success" id="successMsg"></div>
    <div class="error" id="errorMsg"></div>

    <div class="appointments" id="appointmentList"></div>
  </div>

  <script>
    const form = document.getElementById('bookingForm');
    const successMsg = document.getElementById('successMsg');
    const errorMsg = document.getElementById('errorMsg');
    const appointmentList = document.getElementById('appointmentList');
    const dateInput = document.getElementById('date');
    const timeSelect = document.getElementById('time');

    // Mai dátum beállítása és minimumként beállítása
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const todayStr = `${yyyy}-${mm}-${dd}`;
    dateInput.value = todayStr;
    dateInput.min = todayStr;

    // Foglalt időpontok betöltése és megjelölése
    function loadOccupiedSlots() {
      fetch('foglal.php')
        .then(response => response.json())
        .then(data => {
          const timeOptions = timeSelect.querySelectorAll('option');
          timeOptions.forEach(option => {
            if (option.value) {
              option.classList.remove('occupied');
              const isOccupied = data.occupied_slots.some(slot => 
                slot.date === dateInput.value && slot.time === option.value
              );
              if (isOccupied) {
                option.classList.add('occupied');
                option.disabled = true;
              } else {
                option.disabled = false;
              }
            }
          });
        })
        .catch(error => {
          console.error('Hiba a foglalt időpontok betöltésekor:', error);
        });
    }

    document.getElementById('date').addEventListener('change', function() {
      const selectedDate = new Date(this.value);
      const dayOfWeek = selectedDate.getDay(); // 0=Vasárnap, 6=Szombat
      
      // Hétvége ellenőrzése
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        alert('Hétvégén nem lehet időpontot foglalni!');
        this.value = '';
        const nextMonday = new Date(selectedDate);
        nextMonday.setDate(selectedDate.getDate() + (8 - dayOfWeek) % 7);
        this.value = nextMonday.toISOString().split('T')[0];
      }
    });
    
    // Űrlap beküldése
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Űrlap adatainak összegyűjtése
      const reason = document.getElementById('reason').value;
      const date = document.getElementById('date').value;
      const time = document.getElementById('time').value;
      
      // Hibaüzenetek törlése
      successMsg.textContent = '';
      errorMsg.textContent = '';
      
      // Adatok küldése a szervernek
      fetch('foglal.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reason: reason,
          date: date,
          time: time
        })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          successMsg.textContent = data.message;
          form.reset();
          dateInput.value = todayStr;
          loadOccupiedSlots();
        } else {
          errorMsg.textContent = data.message;
        }
      })
      .catch(error => {
        console.error('Hiba:', error);
        errorMsg.textContent = 'Hiba történt a foglalás során.';
      });
    });

    // Dátum változásakor frissítjük a foglalt időpontokat
    dateInput.addEventListener('change', loadOccupiedSlots);

    // Oldal betöltésekor betöltjük a foglalt időpontokat
    document.addEventListener('DOMContentLoaded', loadOccupiedSlots);
  </script>
</body>
</html>