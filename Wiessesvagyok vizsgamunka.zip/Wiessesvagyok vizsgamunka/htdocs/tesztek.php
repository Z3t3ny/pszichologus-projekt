<html><head>
    <link rel="shortcut icon" href="/wmicon.ico" type="image/vnd.microsoft.icon">
    <title> WEISSes vagyok </title>

    <link href="pszihologus.css" type="text/css" rel="stylesheet">
</head>

<body>
<div id="tartalom">
<h1> Tesztek </h1>

<div id="szoveg">

    <p>
	Ezen az oldalon különböző érdekes önismereti tesztek fognak szerepelni, melyeket majd kitöltve akár 
	picit jobban megismerheted saját magadat is. 
    </p>

</div>

    </div>




</body></html>