<!DOCTYPE html>
<html lang="hu">
<head>
    <link rel="stylesheet" href="pszichologus.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>pszichologus</title>
</head>
<body>
  <div class="intro-container">
    <div class="image-container">
      <img src="\Kintakia\profilkepek\1_250130103552.jpg" alt="Profile Image" class="circular-image">
    </div>
    <div class="content" id="content">
        <h1 id="introduction">Introduction</h1>
        <p id="introduction1">""</p>
    </div>
  </div>

  <my-collection>
        <my-card class="forest-card">
            <card-title>Nature Card</card-title>
            <card-content>This green card represents the beauty of nature. Hover over me to see a special effect!</card-content>
        </my-card>
        
        <my-card class="cloud-card">
            <card-title>Cloud Card</card-title>
            <card-content>This white card floats like a cloud in the sky. Hover to discover its transformation!</card-content>
        </my-card>
        
        <my-card class="forest-card">
            <card-title>Forest Card</card-title>
            <card-content>This second green card brings the forest to life. Hover to experience the magic!</card-content>
        </my-card>
    </my-collection>
    <div class="button-container">
    <a href="idopontfoglalas" class="idopontbutton">időpontfoglalás</a>
    </div>

  <footer>
        <div class="footer-content">
            <h3>Connect With Us</h3>
            <div class="social-links">
                <a href="mailto:contact@example.com">
                    <svg class="social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                    </svg>
                    contact@example.com
                </a>
                <a href="https://m.me/examplepage" target="_blank">
                    <svg class="social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.14 7.17.16.13.26.35.27.57l.05 1.78c.04.57.61.94 1.13.71l1.98-.87c.17-.07.36-.1.53-.1.12 0 .24.03.36.05 1.03.17 2.07.26 3.15.26 5.64 0 10-4.13 10-9.7C22 6.13 17.64 2 12 2zm6 7.46l-2.93 4.67c-.47.73-1.47.92-2.17.37l-2.34-1.73a.6.6 0 0 0-.72 0l-3.16 2.4c-.42.33-.97-.17-.68-.61l2.93-4.67c.47-.73 1.47-.92 2.17-.37l2.34 1.73a.6.6 0 0 0 .72 0l3.16-2.4c.42-.33.97.17.68.61z"/>
                    </svg>
                    Messenger
                </a>
                <a href="https://instagram.com/exampleaccount" target="_blank">
                    <svg class="social-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41-.56-.22-.96-.48-1.38-.9-.42-.42-.68-.82-.9-1.38-.16-.42-.36-1.06-.41-2.23-.06-1.27-.07-1.65-.07-4.85s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41 1.27-.06 1.65-.07 4.85-.07M12 0C8.74 0 8.33.01 7.05.07 5.78.13 4.9.33 4.14.63 3.35.95 2.66 1.38 2.01 2.01c-.63.63-1.06 1.33-1.38 2.13C.33 4.9.13 5.78.07 7.05.01 8.33 0 8.74 0 12s.01 3.67.07 4.95c.06 1.27.26 2.15.56 2.91.32.8.75 1.48 1.38 2.13.65.63 1.33 1.06 2.13 1.38.76.3 1.64.5 2.91.56 1.28.06 1.69.07 4.95.07s3.67-.01 4.95-.07c1.27-.06 2.15-.26 2.91-.56.8-.32 1.48-.75 2.13-1.38.63-.65 1.06-1.33 1.38-2.13.3-.76.5-1.64.56-2.91.06-1.28.07-1.69.07-4.95s-.01-3.67-.07-4.95c-.06-1.27-.26-2.15-.56-2.91-.32-.8-.75-1.48-1.38-2.13-.65-.63-1.33-1.06-2.13-1.38-.76-.3-1.64-.5-2.91-.56C15.67.01 15.26 0 12 0zm0 5.84c-3.4 0-6.16 2.76-6.16 6.16 0 3.4 2.76 6.16 6.16 6.16 3.4 0 6.16-2.76 6.16-6.16 0-3.4-2.76-6.16-6.16-6.16zm0 10.15c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm6.41-11.84c-.8 0-1.44.64-1.44 1.44s.64 1.44 1.44 1.44c.8 0 1.44-.64 1.44-1.44s-.64-1.44-1.44-1.44z"/>
                    </svg>
                    Instagram
                </a>
            </div>
            <p class="copyright">&copy; 2025 Your Company Name. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>