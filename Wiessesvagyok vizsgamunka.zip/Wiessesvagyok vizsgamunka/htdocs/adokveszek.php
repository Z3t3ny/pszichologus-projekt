<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="stylesheet" href="marketplace.css">

    <style>
        /* Modális ablak alap stílusai */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 800px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        #modalProductContent {
            display: flex;
            flex-direction: row;
            align-items: center;
        }

        #modalProductContent img {
            width: 200px;
            height: 200px;
            object-fit: cover;
            border-radius: 50%;
        }

        #modalProductContent .product-details {
            margin-left: 20px;
        }

        #modalProductContent .user-profile {
            display: flex;
            flex-direction: row;
            align-items: center;
        }

        #modalProductContent .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
    </style>
</head>
<body>

    <div class="scontainer">
        <input type="checkbox" id="sidebar-toggle" style="display:none;">
        <label for="sidebar-toggle">
        <div class="sidebar-toggle">-></div>
        </label>
        <div class="sidebar">
        <button class="close-button">×</button>

        <aside>
            <!-- Keresősáv -->
            <div class="search-bar">
                <input type="text" placeholder="Keress termékeket...">
            </div>
            <input type="submit" value="Keresés" class="log">

            <!-- Ár szűrő -->
            <div class="price-filter">
                <h3>Árkategória</h3>
                <input type="range" id="price-range" min="0" max="50000" step="100" value="25000" oninput="updatePrice(this)">
                <p>Maximum ár: <span id="price-value">25 000</span> Ft</p>
            </div>

            <!-- Kategóriák -->
            <div class="categories">
                <label for="categories">Kategóriák</label>
                <select id="categories" name="categories">
                    <option value="ruházat">Ruházat</option>
                    <option value="elektronika">Elektronika</option>
                    <option value="háztartás">Háztartás</option>
                    <option value="egyéb">Egyéb</option>
                </select>
            </div>

            <!-- Termék állapota (rádiógombok) -->
            <div class="product-condition">
                <h3>Termék állapota</h3>
                <label><input type="radio" name="condition" value="új"> Új</label><br>
                <label><input type="radio" name="condition" value="újszerű"> Újszerű</label><br>
                <label><input type="radio" name="condition" value="használt"> Használt</label>
            </div>

            <div id="linkek">
                <a href="kedvencek" class="gomb1">Kedvencek</a>
                <a href="sajathirdetes" class="gomb2">Saját hirdetések</a>
                <a href="feltoltes" class="gomb3">Termék(ek) feltöltése</a>
            </div>
        </aside>
        </div>

        <main>
            <section id="products" class="products">
                <h2>Elérhető termékek</h2>

                <?php 
                // PHP kód a termékek megjelenítésére
                print("<div class='product-grid'>");
                $conn = new mysqli("sql204.infinityfree.com", "if0_38415749", "wbEJgydD4SM", "if0_38415749_wv");
                if ($conn->connect_error) {
                    die("Kapcsolódási hiba: " . $conn->connect_error);
                }

                $sql = "SELECT tid, tnev, tar, tkep, tleiras, tkep, tuid
                        FROM termekek, user
                        WHERE tuid=uid";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='product-card'>";
                        echo "<div class='product-image-container'>";
                        echo "<img src='./termekkepek/$row[tkep]' id='nkep' alt='" . $row['tnev'] . "'>";
                        echo "</div>";
                        echo "<div id='valami'>";
                        echo "<h3>" . $row['tnev'] . "</h3>";
                        echo "<hr>";
                        echo "<p>" . $row['tar'] . " Ft</p>";

                        // Részletek gomb és modális ablakhoz tartozó adatok
                        echo "<button class='openModalBtn' data-tid='" . $row['tid'] . "'>Részletek megtekintése</button>";
                        echo "</div></div>";
                    }
                } else {
                    echo "Nincsenek termékek.";
                }
                $conn->close();
                print("</div>");
                ?>
            </section>
        </main>
    </div>

    <!-- Modal ablak -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div id="modalProductContent">
                <img id="modalProductImage" src="" alt="" style="width: 100%; max-width: 400px;">
                <div class="product-details">
                    <h2 id="modalProductName"></h2>
                    <p id="modalProductPrice"></p>
                    <p id="modalProductDescription"></p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Modal ablak elemek
        const modal = document.getElementById("productModal");
        const closeModalBtn = document.querySelector('.close');

        // Modal ablak bezárása
        closeModalBtn.onclick = function() {
            modal.style.display = "none";
        };

        // Nyitás gombok kezelése
        document.querySelectorAll('.openModalBtn').forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-tid');
                fetchProductDetails(productId);
                modal.style.display = "block";
            });
        });

        // A termékek adatainak betöltése
        function fetchProductDetails(tid) {
            // Lekérjük a termék részleteit
            fetch(`termek_reszletek.php?tid=${tid}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Hiba történt a válasz feldolgozása közben');
                    }
                    return response.json(); // Válasz JSON formátumban
                })
                .then(data => {
                    // Adatok hozzáadása a modal ablakhoz
                    if (data.error) {
                        console.log(data.error);
                    } else {
                        document.getElementById("modalProductName").textContent = data.tnev;
                        document.getElementById("modalProductPrice").textContent = data.tar + " Ft";
                        document.getElementById("modalProductDescription").textContent = data.tleiras;
                        document.getElementById("modalProductImage").src = "./termekkepek/" + data.tkep;
                    }
                })
                .catch(error => {
                    console.error('Hiba a termékadatok betöltésekor:', error);
                });
        }

        // Modális ablak bezárása
        function closeModal() {
            modal.style.display = "none";
        }
    </script>
</body>
</html>
