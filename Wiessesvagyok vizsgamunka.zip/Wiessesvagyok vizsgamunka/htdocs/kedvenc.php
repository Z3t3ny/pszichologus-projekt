<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kedvencek - Marketplace</title>
    <link rel="stylesheet" href="kedvenc.css"> <!-- A CSS fájl linkelése -->
</head>
<body>


    <div class="container">
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Keresés a kedvencek között..." oninput="searchProducts()">
        </div>

        <div id="productGrid" class="product-grid">
            <!-- A termékek dinamikusan kerülnek ide -->
        </div>

        <!-- Üres állapot -->
        <div id="emptyState" class="empty-state" style="display: none;">
            <img src="https://via.placeholder.com/100" alt="No items">
            <p>Nincsenek kedvenc termékeid. Böngéssz és szívezd meg a neked tetszőket!</p>
        </div>
    </div>

    <script>
    // // Termékadatok (ezeket dinamikusan jövőbeli adatbázisból kellene lekérni)
    // const products = [
    //     { id: 1, name: "Termék 1", price: "4990 Ft", image: "https://via.placeholder.com/300x200?text=Termék+1" },
    //     { id: 2, name: "Termék 2", price: "2490 Ft", image: "https://via.placeholder.com/300x200?text=Termék+2" },
    //     { id: 3, name: "Termék 3", price: "3990 Ft", image: "https://via.placeholder.com/300x200?text=Termék+3" },
    //     { id: 4, name: "Termék 4", price: "1590 Ft", image: "https://via.placeholder.com/300x200?text=Termék+4" }
    // ];

    // const productGrid = document.getElementById('productGrid');
    // const emptyState = document.getElementById('emptyState');
    
    // // Funkció a termékek megjelenítésére
    // function renderProducts() {
    //     productGrid.innerHTML = '';
    //     if (products.length === 0) {
    //         emptyState.style.display = 'block';
    //     } else {
    //         emptyState.style.display = 'none';
    //         products.forEach(product => {
    //             const productCard = document.createElement('div');
    //             productCard.classList.add('product-card');

    //             productCard.innerHTML = `
    //                 <img src="${product.image}" class="product-image" alt="${product.name}">
    //                 <div class="product-details">
    //                     <h3>${product.name}</h3>
    //                     <p class="product-price">${product.price}</p>
    //                     <div class="buttons">
    //                         <button onclick="removeFromFavorites(${product.id})">Eltávolítás</button>
    //                     </div>
    //                 </div>
    //             `;
    //             productGrid.appendChild(productCard);
    //         });
    //     }
    // }

    //     // Termék eltávolítása a kedvencek közül
    //     function removeFromFavorites(productId) {
    //         const index = products.findIndex(product => product.id === productId);
    //         if (index !== -1) {
    //             products.splice(index, 1);
    //             renderProducts();
    //         }
    //     }

    //     // Keresés a kedvencek között
    //     function searchProducts() {
    //         const query = document.getElementById('searchInput').value.toLowerCase();
    //         const filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));
    //         renderProducts(filteredProducts);
    //     }

    //     // Kezdeti renderelés
    //     renderProducts();
    </script>

                <?php print("<div class='product-grid'>") ?>
                <?php
                    $conn = new mysqli("sql204.infinityfree.com", "if0_38415749", "wbEJgydD4SM", "if0_38415749_wv");
                    if ($conn->connect_error) {
                        die("Kapcsolódási hiba: " . $conn->connect_error);
                    }

                    $sql = "SELECT t.tid, t.tnev, t.tar, t.tkep
                            FROM termekek t
                            INNER JOIN kedvencek k ON t.tid = k.ketid
                            WHERE k.keuid = $_SESSION[uid]";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {    
                            echo "<div class='product-card'>";    
                            echo "<img src='./termekkepek/$row[tkep]' class='product-image' alt='" . $row['tnev'] . "' >";
                            echo "<h3>" . $row['tnev'] . "</h3>";
                            echo "<hr>";
                            echo "<p class='product-price'>" . $row['tar'] . " Ft</p>";
                            echo "<input type='hidden' name='productId' value='" . $row['tid'] . "'>";
                            echo "<div class='buttons'>
                                  <button onclick='removeFromFavorites($row[tid])'>Eltávolítás</button>
                                  </div>";
                            echo "</div>";
                        }
                    } else {
                        echo "Nincsenek termékek.";
                    }
                    $conn->close();
                    
                 print("</div>") ?>
     
</body>
</html>