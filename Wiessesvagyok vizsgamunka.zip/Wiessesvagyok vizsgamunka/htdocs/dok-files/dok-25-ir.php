<?php
include("kapcsolat.php")

mysqli_query( $adb , "

		UPDATE friendship SET  (fid ,  fuid  ,         ffid  ,     fstatus)
		VALUES                 (NULL, '$_SESSION[uid]' , '$_POST[ffid]', 'A')


	" ) ;

?>