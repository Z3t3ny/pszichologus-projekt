<!DOCTYPE html>
<html lang="hu">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
        <script src="social.js"></script>
        
    </head>
    <style>


    a.ivlink
    {
	display          : flex           ;
	margin           : 24px 60px      ;
	padding          : 12px 24px      ;
	background-color : #DDE           ;
	border           : solid 2px #097 ;
	border-radius    : 6px            ;
	color            : #333           ;
	text-decoration  : none           ;
    align-items:center;
    }

    a.ivlink:hover
    {
	background-color : #EEF           ;
	border           : solid 2px #0EB ;
	text-decoration  : none!important ;
    }

    a.ivlink h1 , a.ivlink h2 , a.ivlink h3
    {
	margin           : 0              ;
	color            : #555           ;
	font-size        : 1em            ;
    }

    a.ivlink h2
    {
	font-weight      : normal         ;
    }

    a.ivlink img
    {
	
    
	width            : 72px           ;
	border-radius    : 50%            ;
	opacity          : 75%            ;
    }
    
    a.ivlink:hover img
    {
	opacity          : 1              ;
    }


</style>
<body>






<div class="addFriendBtnContainer">
    <div id="backToChatsBtn">
        <a class="ivlink" href="social"><img src="images/laci2xd.png"><h1>Beszélgetések</h1></a>
    </div>
</div>



<div class="socialSearchBarContainer">
    <input type="text" id="social-searchbar">
</div>

<div class="userSearchContainer">

<div>
<form action='socialsearch_ir.php' method='POST' target='kisablak' id="peopleForm">

<?php
$query = mysqli_query($adb, "SELECT *
FROM user
INNER JOIN om ON user.uom = om.omom
");

$om = mysqli_fetch_array(mysqli_query($adb, "
    
                        SELECT *
                        FROM user
                        INNER JOIN om ON om.omom = user.uom
                        WHERE uid = '$_SESSION[uid]';


    "));

    $oszt = $om['omoszt'];



while ($users = mysqli_fetch_assoc($query)) {   
    
    $punick = $users['unick']; // Directly use the fetched row
    $puid = $users['uid'];
    $puoszt = $users['omoszt'];
    
    
    
    if($puoszt = $oszt){
    
    echo '
    <form action="socialsearch_ir.php" method="POST" target="kisablak">
    <input type="hidden" name="ffid" value="'.$puid.'">
    <input type="hidden" name="puom" value="'.$puoszt.'">
                <a href="#">
                    <button type="submit" class="ivlink" id="person" onclick=" setTimeout(function() {window.parent.location.reload()}, 20)">   
                        <h1 id="person_h1">'.$punick.'</h1>
                        <h1 id="person_h1">'.$puoszt.'</h1>
                    </button>
                </a>
            </form>
    ';
    }
    }



?>
</form>



</div>
   

</div>

</body>
</html>