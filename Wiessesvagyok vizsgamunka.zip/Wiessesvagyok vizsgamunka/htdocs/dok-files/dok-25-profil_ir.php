<?php
    session_start();

    print "<hr>" ;

    if(!isset($_SESSION['uid']))
                die( "<script> 
                        alert('Lejárt a munkamanet! Jelentkezz be ismét!')
                        parent.location.href='belepes'

                        
                    </script>" );

    print_r ( $_POST ) ;
    print   ("<hr>");
    print_r ( $_FILES ) ;


   

    include("kapcsolat.php") ;


	  

	$sorokszama = mysqli_num_rows( mysqli_query( $adb , " 

							SELECT * FROM user 
							WHERE uemail='$_POST[uemail]' 
							AND (ustatusz='A' OR ustatusz='F' OR ustatusz='E') 
                            AND uid!= '$_SESSION[uid]'
	" ) ) ;

	if( $sorokszama>0 )  
		die( "<script> alert('Ez az e-mail cím már használatban van!!') </script>" ) ;


	if( mysqli_num_rows( mysqli_query( $adb , " 

							SELECT * FROM korabbinev 
							WHERE kunick='$_POST[unick]' 
                            AND kuid !='$_SESSION[uid]'
	" ) ) )
		die( "<script> alert('Ez a felhasználónév már foglalt!') </script>" ) ;


	$md5pw = md5( $_POST['upw'] ) ;

    $sorokszama = mysqli_num_rows( mysqli_query( $adb, "
    
						
                            SELECT * FROM user
                            WHERE uid='$_SESSION[uid]' 
                            AND upw ='$md5pw'


				")) ;
                
    if ($sorokszama == 0)
            die("<script>alert('Hibás a megadott jelszavad!')</script>");

 


    $kep = $_FILES['uprofkep'];
    if($kep['name'] != ""){

        $ujkepnev = $_SESSION['uid'] . "_" . date("ymdHis");
        if($kep['type'] == "image/jpeg")$ujkepnev .= ".jpg"; else
        if($kep['type'] == "image/png")$ujkepnev .= ".png";  else
        die("<script>alert('A kép csak JPG vagy PNG lehet!')</script>");
        move_uploaded_file( $kep['tmp_name'] , "./profilkepek/" . $ujkepnev);
        
        mysqli_query( $adb, "

                            UPDATE user
                            SET   uprofkepnev            = '$ujkepnev',
                                  uprofkep_eredetinev    = '$kep[name]'

                            WHERE uid    = '$_SESSION[uid]'

            ");
    } 
    $weisstag = "@wm-iskola.hu";

    mysqli_query( $adb, "

                            UPDATE user
                            SET   unick                  = '$_POST[unick]'            , 
                                  unev                   = '$_POST[unev]'             ,
                                  uemail                 = '$_POST[uemail]'           ,
                                  uwmailtag              = '$_POST[uwmail]'           ,
                                  uwmail                 = '$_POST[uwmail]$weisstag'  ,
                                  

                            WHERE uid    = '$_SESSION[uid]'

            ");
    
    $sorokszama = mysqli_num_rows( mysqli_query( $adb, "
    
						
                            SELECT kunick FROM korabbinev
                            WHERE kuid !='$_SESSION[uid]' 
                        


    ")) ;
    if($_SESSION['unick'] != $_POST['unick']){
           
                mysqli_query( $adb , "

                INSERT INTO korabbinev ( kid  ,  kuid           ,         kunick  , kdatum , kstatusz) 
                VALUES                 ( NULL , '$_SESSION[uid]',  '$_POST[unick]', NOW()  , ''      )


                " );
                
            }
            

    $_SESSION['unick'] = $_POST['unick'];




   

   
    
    print(
        "<script>
        
        alert('Az adataidat sikeresen módosítottuk!')
        parent.location.href='http://localhost/zz/wvp/kezdolap'

        </script>");
    mysqli_close( $adb ) ;
?>