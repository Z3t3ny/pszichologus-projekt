<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="feltoltes.css">
    <title>Marketplace - Termékfeltöltés</title>
</head>
<body>
    <div class="feltoltesfejlec">
        <h2>Termékfeltöltés</h2>
    </div>
<div id="betu">

        <form action="feltoltes_ir.php" method="POST" enctype="multipart/form-data" id="feltoltesform" target='kisablak'>
            <label for="product_name">Termék neve:</label>
            <input type="text" id="product_name" name="product_name" required>

            <label for="description">Leírás:</label>
            <textarea id="description" name="description" rows="5" required></textarea>

            <label for="price">Ár (HUF):</label>
            <input type="number" id="price" name="price" step="5" min="0" required>

            <label for="category">Kategória:</label>
            <select id="category" name="category" required>
                <option value="">Válassz kategóriát</option>
                <option value="elektronika">Elektronika</option>
                <option value="ruházat">Ruházat</option>
                <option value="háztartás">Háztartás</option>
                <option value="egyéb">Egyéb</option>
            </select>

            <label for="image">Termék kép feltöltése:</label>
            <input type="file" id="image" name="image" required>

            <input class="log" type="submit" value="Termék feltöltése">
        </form>
</div>
    <a href="adokveszek" class="log2">Vissza a főoldalra</a>
</body>
</html>