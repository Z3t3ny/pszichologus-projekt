<?php
// Adatbázis kapcsolat létrehozása
$servername = "localhost";
$username = "root";  // Módosítsd a valódi felhasználónevedre
$password = "";      // Módosítsd a valódi jelszavadra
$dbname = "wv";

// Kapcsolat létrehozása
$conn = new mysqli($servername, $username, $password, $dbname);

// Kapcsolat ellenőrzése
if ($conn->connect_error) {
    die("Sikertelen kapcsolódás: " . $conn->connect_error);
}

// UTF-8 karakterkódolás beállítása
$conn->set_charset("utf8");
?>