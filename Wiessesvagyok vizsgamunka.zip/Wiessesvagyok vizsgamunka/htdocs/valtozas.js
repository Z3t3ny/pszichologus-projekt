const form = document.getElementById('profilform');
const gomb = document.getElementById('profilformgomb');
const kezdetiErtekek = {};
const inputok = form.querySelectorAll('input');

// Mentjük az inputok kezdeti értékeit
inputok.forEach(input => {
  kezdetiErtekek[input.name] = input.value;
});

function ellenorizValtozasokat() {
  let vanValtozas = false;

  inputok.forEach(input => {
    const current = input.value;
    const kezdeti = kezdetiErtekek[input.name];

    const nemErdekes = input.classList.contains('neszinezd');

    if (current !== kezdeti) {
      if (!nemErdekes) {
        vanValtozas = true;
      }

      if (input.classList.contains('szinezendok')) {
        input.classList.add('valtozott');
        input.placeholder = "Mentetlen változtatások";
      }
    } else {
      if (input.classList.contains('szinezendok')) {
        input.classList.remove('valtozott');
      }
    }
  });

  if (vanValtozas) {
    gomb.classList.add('lathato');
  } else {
    gomb.classList.remove('lathato');
  }
}

// Eseményfigyelő minden inputra
form.addEventListener('input', (event) => {
  if (event.target.tagName === 'INPUT') {
    ellenorizValtozasokat();
  }
});
