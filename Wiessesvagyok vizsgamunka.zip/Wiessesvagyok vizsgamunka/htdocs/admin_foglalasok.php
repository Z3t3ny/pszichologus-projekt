<?php
session_start();

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Adatbázis kapcsolat létrehozása
require_once 'kapcsolat.php';

// Foglalás jóváhagyása vagy elutasítása
if (isset($_POST['action']) && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $sql = "UPDATE foglalasok SET fstatusz = 'elfogadva' WHERE fid = ?";
        $message = "Foglalás sikeresen jóváhagyva!";
    } elseif ($action === 'reject') {
        $sql = "UPDATE foglalasok SET fstatusz = 'elutasítva' WHERE fid = ?";
        $message = "Foglalás sikeresen elutasítva!";
    } elseif ($action === 'delete') {
        $sql = "DELETE FROM foglalasok WHERE fid = ?";
        $message = "Foglalás sikeresen törölve!";
    }
    
    if (isset($sql)) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $status_message = $message;
        } else {
            $error_message = "Hiba történt: " . $stmt->error;
        }
        
        $stmt->close();
    }
}

// Foglalások lekérdezése
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$where_clause = "";

if ($status_filter === 'pending') {
    $where_clause = "WHERE fstatusz = 'függőben'";
} elseif ($status_filter === 'approved') {
    $where_clause = "WHERE fstatusz = 'elfogadva'";
} elseif ($status_filter === 'rejected') {
    $where_clause = "WHERE fstatusz = 'elutasítva'";
}

$sql = "SELECT * FROM foglalasok $where_clause ORDER BY fdatum, fido";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Foglalások</title>
    <link href="pszichologus.css" type="text/css" rel="stylesheet">
    <style>
        .admin-container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .logout-btn {
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .filter-options {
            margin-bottom: 20px;
        }
        
        .filter-options a {
            margin-right: 10px;
            padding: 8px 12px;
            text-decoration: none;
            color: #333;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .filter-options a.active {
            background-color: #4CAF50;
            color: white;
            border-color: #4CAF50;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        table th {
            background-color: #f8f8f8;
        }
        
        .pending {
            background-color: #fcf8e3;
        }
        
        .approved {
            background-color: #dff0d8;
        }
        
        .rejected {
            background-color: #f2dede;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .approve-btn {
            background-color: #5cb85c;
        }
        
        .reject-btn {
            background-color: #d9534f;
        }
        
        .delete-btn {
            background-color: #292b2c;
        }
        
        button {
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .status-message {
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .error-message {
            background-color: #f2dede;
            color: #a94442;
            border: 1px solid #ebccd1;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="header">
            <h1>Foglalások kezelése</h1>
            <a href="admin_logout.php" class="logout-btn">Kijelentkezés</a>
        </div>
        
        <?php if (isset($status_message)): ?>
            <div class="status-message"><?php echo $status_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="filter-options">
            <a href="?status=all" <?php echo $status_filter === 'all' ? 'class="active"' : ''; ?>>Összes</a>
            <a href="?status=pending" <?php echo $status_filter === 'pending' ? 'class="active"' : ''; ?>>Függőben</a>
            <a href="?status=approved" <?php echo $status_filter === 'approved' ? 'class="active"' : ''; ?>>Elfogadva</a>
            <a href="?status=rejected" <?php echo $status_filter === 'rejected' ? 'class="active"' : ''; ?>>Elutasítva</a>
        </div>
        
        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Név</th>
                        <th>Email</th>
                        <th>Telefon</th>
                        <th>Dátum</th>
                        <th>Időpont</th>
                        <th>Beküldve</th>
                        <th>Státusz</th>
                        <th>Műveletek</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr class="<?php echo strtolower($row['fstatusz']); ?>">
                            <td><?php echo htmlspecialchars($row['fnev']); ?></td>
                            <td><?php echo htmlspecialchars($row['femail']); ?></td>
                            <td><?php echo htmlspecialchars($row['ftelefon'] ?? '-'); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($row['fdatum'])); ?></td>
                            <td><?php echo $row['fido']; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($row['frogzites_datum'])); ?></td>
                            <td><?php echo ucfirst($row['fstatusz']); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <?php if ($row['fstatusz'] === 'függőben'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="id" value="<?php echo $row['fid']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="approve-btn">✓</button>
                                        </form>
                                        <form method="POST">
                                            <input type="hidden" name="id" value="<?php echo $row['fid']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="reject-btn">✗</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" onsubmit="return confirm('Biztosan törölni szeretnéd ezt a foglalást?');">
                                        <input type="hidden" name="id" value="<?php echo $row['fid']; ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="delete-btn">🗑</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Nincs megjeleníthető foglalás.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Kapcsolat bezárása
$conn->close();
?>